BanchatKartcer — Telegram vote-to-ban bot

Render:
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app --workers 1 --threads 2 --timeout 120

Environment variable:
BOT_TOKEN = token from @BotFather

After the Render service is live, open:
https://YOUR-SERVICE.onrender.com/set-webhook

Then add @Banchat_vote_Kartser_bot to the Telegram group as an administrator
with permission to ban/restrict users.

Usage:
Reply to a user's message as an admin:
 /vote причина

The bot opens a 10-minute vote. Minimum 3 votes and at least 60% "За бан"
are required for a ban.
